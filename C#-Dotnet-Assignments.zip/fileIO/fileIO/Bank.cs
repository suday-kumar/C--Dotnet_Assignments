﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fileIO
{
    internal class Bank
    {
        class Account
        {
            public string Name { get; set; }
            public double AccountNumber { get; set; }
            public double balance { get; set; }
        }
        static void Main(string[] args)
        {

            string dir = @"C:\Uday\Bank";
            string srcFilepath = @"C:\Uday\Bank\Account.txt";
            Directory.CreateDirectory(dir);

          //create file and write
            FileStream fs = File.Create(srcFilepath);
                fs.Close();
          //  List<Account> accounts = new List<Account>();
            Account a1 = new Account();
            Console.WriteLine("Enter AccountHolder Name :");
            a1.Name = Console.ReadLine();
            Console.WriteLine("Enter Account Number :");
            a1.AccountNumber = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Account Balance :");
            a1.balance = Convert.ToDouble(Console.ReadLine());
            


            StreamWriter sw = new StreamWriter(srcFilepath);     
                sw.WriteLine(a1.Name);
                sw.WriteLine(a1.AccountNumber);
                 sw.WriteLine(a1.balance);
        
            sw.Close();

            // read and write on console
            StreamReader sr = new StreamReader(srcFilepath);
            string line;

            Console.WriteLine("\nAccounts Details :");
            while ((line= sr.ReadLine()) != null)
            {
                
                Console.WriteLine(line);
            }
         
            Console.ReadLine();
        }
    }
}
