﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fileIO
{

    public class MyStack<Int>  
    {

        static readonly int MAX2 = 500; 
        int top2;                   
        int[] str = new int[MAX2]; 
        public void Push(int data)  //performing push operation
        {
            if (top2 > MAX2)
            {
                Console.WriteLine("Stack Overflow");
            }
            else
            {
                str[top2++] = data;
            }
        }
        public void Pop()  //performing pop operation
        {
            if (top2 < 0)
            {
                Console.WriteLine("Stack Underflow");
            }
            else
            {
                int value = str[top2--];
                Console.WriteLine("Popped Value: " + value);
            }
        }
    }
    internal class CustomClassGeneric
    {
        static void Main(string[] args)
        {
            MyStack<int> cg = new MyStack<int>();
            cg.Push(100);  
            cg.Push(200);

            cg.Pop();
            cg.Pop();
            cg.Pop();
            cg.Pop();//Stack Underflow
            Console.ReadKey();
        }
    }
}