﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace stackException
{

    public class stackEmptyException : ApplicationException
    {
        public override String Message
        {
            get
            {
                return "Stack is Empty";
            }
        }
    }
    public class stackFullException : ApplicationException
        {
            public override String Message
            {
                get
                {
                    return "Stack is Full";
                }
            }
        }
    internal class Program
    { 
        public class myStack
        {
            int[] arr;
            int stackSize =5;
            int peek_value;
            int size_of_array;
            public int myStackPush()
            {
                Stack<int> stack1 = new Stack<int>();
                Console.WriteLine("Enter the size of stack");
                size_of_array = Convert.ToInt32(Console.ReadLine());
                arr = new int[size_of_array];
                Console.WriteLine("Enter the  {0}  stack elements", arr.Length);
                try
                {
                    for (int i = 0; i < arr.Length; i++)
                    {
                    arr[i] = Convert.ToInt32(Console.ReadLine());
                    }
                    foreach (int num in arr)
                    {
                            if (stackSize < size_of_array)
                            {
                                throw new stackFullException();
                            }
                            else
                            {
                                stack1.Push(num);
                            }
                           
                    }
                    if (stack1.Count == 0)
                    {
                        throw new stackEmptyException();
                    }
                    else
                    {
                        peek_value = stack1.Pop();
                    }
                }
                catch (stackEmptyException se)
                {
                    Console.WriteLine(se.Message);
                }
                 catch(stackFullException sf)
                {
                        Console.WriteLine(sf.Message);
                }
                finally
                {
                    Console.WriteLine("stack updated !");
                }
                return peek_value;
            }
        }
        static void Main(string[] args)
        {
            myStack newStack = new myStack();
            int peek = newStack.myStackPush();
            Console.WriteLine("pop element is : {0}", peek);
            Console.ReadKey();
        }

    }
}
