﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cSharpConsole
{
    internal class circle
    {
        static double[] area(double r, double pi)
        {
            double[] ac = new double[2];
            ac[0] = pi * r * r;
            ac[1] = 2 * pi * r;
            return ac;
        }
        static void Main(string[] args)
        {
            double pi = 3.14;
            Console.WriteLine("Enter the Radius of the Circle");
            double r = Convert.ToDouble(Console.ReadLine());
            double[] cArea = new double[2];
            cArea = area(r, pi);
            Console.WriteLine("Area of the Circle : {0} ", cArea[0]);
            Console.WriteLine("\nCircumference of the Circle : {0}", cArea[1]);
            Console.ReadKey();
        }
    }
}
