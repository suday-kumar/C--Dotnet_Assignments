﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cSharpConsole
{
    internal class averageOfMarks
    {
        static void Main(string[] args)
        {
            int max;
            int[] avg_marks = new int[5];

            Console.WriteLine("Highest Average Marks");

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Enter Marks: ");
                avg_marks[i] = Convert.ToInt32(Console.ReadLine());
            }
            max = avg_marks.Max();
            Console.WriteLine("The highest average is " + max);
            Console.ReadKey();
        }
    }
}
