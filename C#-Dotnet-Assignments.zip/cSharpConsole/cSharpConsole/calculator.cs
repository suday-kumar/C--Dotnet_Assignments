﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CalculatorApp
{
    class calculator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the action to be performed");
            Console.WriteLine("Press 1 for Addition");
            Console.WriteLine("Press 2 for Subtraction");
            Console.WriteLine("Press 3 for Multiplication");
            Console.WriteLine("Press 4 for Division \n");
            int action = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Num1");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Num2");
            int num2 = Convert.ToInt32(Console.ReadLine());
            int result = 0;
            switch (action)
            {
                case 1:
                        result = num1 + num2;
                        break;
                case 2:
                        result = num1 - num2;
                        break;
                case 3:
                        result = num1 * num2;
                        break;
                case 4:
                        result = num1 / num2;
                        break;
                default:
                    Console.WriteLine("Please select the Operation");
                    break;
            }
            Console.WriteLine("The result is {0",result);
            Console.ReadKey();
        }
    }
}