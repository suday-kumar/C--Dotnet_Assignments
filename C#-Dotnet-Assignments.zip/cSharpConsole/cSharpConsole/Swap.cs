﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cSharpConsole
{
    internal class swappingTwoIntegers
    {
        static void swap(int n1, int n2)
        {
            int temp = n2;
            n2 = n1;
            n1 = temp;
            Console.WriteLine("After Swap \n{0} {1}", n1, n2);
        }
        static void Main(string[] args)
        {
            int num1 = 17, num2 = 18;
            Console.WriteLine("Before Swap \n{0} {1}", num1, num2);
            swap(num1, num2);
            Console.ReadKey();
        }
    }
}
