﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cSharpConsole
{
    internal class bookDetails
    {
        struct book
        {
            public int bookId;
            public string title;
            public double price;
            enum bookType
            {
                Magazine,
                Novel,
                ReferenceBook,
                Miscellaneous
            };
            public void getBookDetails()
            {
                Console.Write("Book Id : ");
                bookId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Book Title : ");
                title = Console.ReadLine();
                Console.Write("Price of the book : ");
                price = Convert.ToDouble(Console.ReadLine());
                Console.Write("Book Type: ");
            }
            public void viewBookDetails()
            {
                Console.WriteLine("\nBOOK DETAILS");
                Console.WriteLine("\nbook Id :{0}", bookId);
                Console.WriteLine("Title :{0}", title);
                Console.WriteLine("Price :{0}", price);
                Console.WriteLine("BookType :{}");
                Console.ReadKey();

            }
        }

        static void Main(string[] args)
        {
            book b1 = new book();
            b1.getBookDetails();
            b1.viewBookDetails();
        }
    }
}
