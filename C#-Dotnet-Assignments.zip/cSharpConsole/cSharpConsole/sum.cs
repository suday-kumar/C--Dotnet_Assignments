﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cSharpConsole
{
    internal class sumOfIntegers
    {
        static void sumOfArray(int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }
            Console.WriteLine("Sum of array elements is \n" + sum);
        }
        static void Main(string[] args)
        {
            int[] arr1 = new int[10];
            arr1 = new int[] { 2, 4, 6, 1, 4, 7 };
            sumOfArray(arr1);
            Console.ReadKey();
        }
    }
}
