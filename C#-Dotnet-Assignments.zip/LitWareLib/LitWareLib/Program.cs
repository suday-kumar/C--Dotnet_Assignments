﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LitWareLib
{
    internal class Program
    {
        public class Employee
        {
             int EmpNo;
             string EmpName;
            public  double Salary;
             double HRA;
             double TA;
             double DA;
             public double PF;
             public double TDS;
             public double NetSalary;
             public double GrossSalary;
            
            // Get the employee Details 
            public virtual void getDetails()
            {
                Console.WriteLine("Enter Employee ID");
                this.EmpNo=Convert.ToInt32(Console.ReadLine());
                
                Console.WriteLine("Enter Employee Name");
                this.EmpName=Console.ReadLine();
               
                Console.WriteLine("Enter Employee Salary");
                this.Salary=Convert.ToDouble(Console.ReadLine());
            }
            //Calculate the Employee Gross Salary per Month
            public virtual double Gsalary()
            {
                if (Salary < 5000 )
                {
                    this.HRA = (Salary *10) / 100;
                    this.TA = (Salary * 5) / 100;
                    this.DA = (Salary * 15) / 100;  
                }
                else if (5000<= Salary && Salary < 10000)
                {
                    this.HRA = (Salary * 15) / 100;
                    this.TA = (Salary * 10) / 100;
                    this.DA = (Salary * 20) / 100;
                }
                else if (10000 <= Salary && Salary < 15000)
                {
                    this.HRA = (Salary * 20) / 100;
                    this.TA = (Salary * 15) / 100;
                    this.DA = (Salary * 25) / 100;
                }
                else if (15000 <= Salary && Salary < 20000)
                {
                    this.HRA = (Salary * 25) / 100;
                    this.TA = (Salary * 20) / 100;
                    this.DA = (Salary * 30) / 100;
                }
                else 
                 {
                    this.HRA = (Salary * 30) / 100;
                    this.TA = (Salary * 25) / 100;
                    this.DA = (Salary * 35) / 100;
                }
                return GrossSalary = Salary + HRA + TA + DA;

            }
           // Calculate the Total Salry of employee per month
            public virtual double CalculateSalary()
            {
                this.PF = (GrossSalary * 10) / 100 ;
                this.TDS= (GrossSalary * 18 )/ 100 ;
                return NetSalary=GrossSalary - PF+TDS;
                
            }
        }
        public class Manager : Employee
        {
            double PA;
            double FA;
            double OA;
            double managerGsalary;
            public override double Gsalary()
            {
                base.Gsalary();
                this.PA = Salary * 8 / 100;
                this.FA = Salary * 13 / 100;
                this.OA = Salary * 3 / 100;

                return managerGsalary = base.GrossSalary + PA + FA + OA;
            }
            public override double CalculateSalary()
            {
                base.CalculateSalary();
                return this.NetSalary = base.NetSalary - PA + TDS;

            }
            public class marketingEx : Employee
            {

                public override double Gsalary()
                {
                    base.Gsalary();
                    Console.WriteLine("Enter Kms");
                    int kmTravel = Convert.ToInt32(Console.ReadLine()); ;
                    double TA = kmTravel * 5;
                    double OA = 1000;
                    double mrktEx;
                 return mrktEx = base.GrossSalary + TA + OA;
                }
                public override double CalculateSalary()
                {
                    base.CalculateSalary();
                    return this.NetSalary = base.NetSalary - PF + TDS;
                }
            }
         
            static void Main(string[] args)
            {
                
                Manager mng = new Manager();
                mng.getDetails();
                double mGsalary = mng.Gsalary();
                Console.WriteLine("Manager Gross Salary {0}", mGsalary);
                

                marketingEx mEx= new marketingEx();
                mEx.getDetails();
                double exGsalary = mEx.Gsalary();
                Console.WriteLine("Excecutive Gross Salary {0}", exGsalary);
                Console.ReadKey();
            }
        }
    }
}
